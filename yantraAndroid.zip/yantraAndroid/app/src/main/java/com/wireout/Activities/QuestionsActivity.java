package com.wireout.Activities;

import android.os.Bundle;
import androidx.annotation.Nullable;


import com.wireout.R;

/**
 * Created by Rishabh on 3/11/2018.
 */

public class QuestionsActivity extends BaseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.questions_layout);

    }
}
