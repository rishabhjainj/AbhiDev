package com.wireout.Exams;

import com.wireout.viewactions.BaseViewAction;

public interface ExamViewAction extends BaseViewAction {

}
