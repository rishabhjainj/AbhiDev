package com.wireout.viewactions;

/**
 * Created by Rishabh on 3/31/2018.
 */

public interface VideosViewAction extends BaseViewAction{


}
