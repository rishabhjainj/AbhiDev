package com.wireout.fourpicsoneword;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


import com.wireout.Activities.BaseActivity;
import com.wireout.R;


/**
 * Created by Paras on 8/6/2017.
 */

public class GuessOver extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        //setContentView(R.layout.game3_game_over_screen);
//        //((TextView) findViewById(R.id.result)).setText("You answered " + mcorrect + " questions correctly and " + mincorrect + " incorrectly!");
//
//        Button b = (Button) findViewById(R.id.start_next_game);
//        b.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(GuessOver.this, GameIntro.class);
//                startActivity(i);
//            }
//        });
//    }
    }
}
