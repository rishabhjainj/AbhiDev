package com.wireout.viewactions;

public interface SignUpViewAction extends BaseViewAction {
    void startLoginActivity();
}
