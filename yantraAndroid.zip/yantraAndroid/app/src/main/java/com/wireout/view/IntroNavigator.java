package com.wireout.view;

/**
 * Created by nikhiljain on 1/31/17.
 */

public interface IntroNavigator {
    void startMainActivity();

    void startPreferencesActivity();
}
