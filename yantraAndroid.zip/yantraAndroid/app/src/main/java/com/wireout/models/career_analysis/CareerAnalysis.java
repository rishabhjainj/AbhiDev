package com.wireout.models.career_analysis;

import java.io.Serializable;

public class CareerAnalysis implements Serializable{

    Integer section1, section2, section3, section4, section5;
    String section6;
    Integer section7, section8, section9, section10, section11, section12, section13;

    public Integer getSection1() {
        return section1;
    }

    public Integer getSection2() {
        return section2;
    }

    public Integer getSection3() {
        return section3;
    }

    public Integer getSection4() {
        return section4;
    }

    public Integer getSection5() {
        return section5;
    }

    public String getSection6() {
        return section6;
    }

    public Integer getSection7() {
        return section7;
    }

    public Integer getSection8() {
        return section8;
    }

    public Integer getSection9() {
        return section9;
    }

    public Integer getSection10() {
        return section10;
    }

    public Integer getSection11() {
        return section11;
    }

    public Integer getSection12() {
        return section12;
    }

    public Integer getSection13() {
        return section13;
    }
}
