package com.wireout.view;



public interface SplashNavigator {
    void startMainActivity();

    void startLoginActivity();

    void startIntroActivity();
}

