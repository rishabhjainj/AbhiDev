package com.wireout.listeners.auth;

import com.wireout.models.User;

/**
 * Created by sharda on 24/02/18.
 */

public interface OnCreateUserListener {
    void onUserCreated(User user);

}
