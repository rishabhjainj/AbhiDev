package com.wireout.models;

/**
 * Created by rahul on 19/3/18.
 */

public class Library {

    String topic;

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }
}
