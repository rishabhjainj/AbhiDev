package com.wireout.apiservices.responses;

/**
 * Created by Rishabh on 3/4/2018.
 */

public class GenericResponse {

}
