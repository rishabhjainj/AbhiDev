package com.wireout.videos;

/**
 * Created by rahul on 21/2/18.
 */

public class Config {

    public static final String DEVELOPER_KEY = "AIzaSyCzjrXzMDzxuA3fZoqyQb_1q4H-NhiXjhM";

}
