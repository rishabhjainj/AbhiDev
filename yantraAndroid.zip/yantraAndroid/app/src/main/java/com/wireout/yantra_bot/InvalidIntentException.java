package com.wireout.yantra_bot;

public class InvalidIntentException extends Exception {
    InvalidIntentException(String message){
        super(message);
    }
}
