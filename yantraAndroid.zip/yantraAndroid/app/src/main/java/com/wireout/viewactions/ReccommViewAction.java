package com.wireout.viewactions;

/**
 * Created by Rishabh on 1/5/2018.
 */

public interface ReccommViewAction extends BaseViewAction {
    void showNetworkTimeoutError();
    void showNoNetworkException();
}
