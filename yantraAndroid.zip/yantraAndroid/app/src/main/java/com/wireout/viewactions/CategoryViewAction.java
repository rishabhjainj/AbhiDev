package com.wireout.viewactions;

import com.wireout.models.Category;

public interface CategoryViewAction extends BaseViewAction {
    void initUi(Category category);
}
