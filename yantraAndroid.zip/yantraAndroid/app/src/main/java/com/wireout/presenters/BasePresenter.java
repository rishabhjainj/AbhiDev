package com.wireout.presenters;

import com.wireout.apiservices.Repository;

/**
 * Created by sharda on 24/02/18.
 */

abstract public class BasePresenter{

    protected Repository repository = new Repository();


}
