package com.wireout.HelpDesk;

import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;


import com.wireout.Activities.BaseActivity;
import com.wireout.R;

public class RefundsActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refunds);
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(newBase);
    }

    @Override
    public void showMessage(String message) {
        super.showMessage(message);
    }

    @Override
    public void showNetworkError(String message) {
        super.showNetworkError(message);
    }
}
