package com.wireout.models.career_analysis;

public class ExamDetail {
    String name, date;
    Float score;

}
