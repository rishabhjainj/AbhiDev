package com.wireout.viewactions;

/**
 * Created by sharda on 24/02/18.
 */

public interface BaseViewAction {
    public void showMessage(String message);
    public void showNetworkError(String message);


}

