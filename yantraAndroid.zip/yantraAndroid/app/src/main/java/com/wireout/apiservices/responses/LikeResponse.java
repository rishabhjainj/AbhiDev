package com.wireout.apiservices.responses;

/**
 * Created by Rishabh on 3/29/2018.
 */

public class LikeResponse {
    Boolean liked;

    public Boolean getLiked() {
        return liked;
    }

    public void setLiked(Boolean liked) {
        this.liked = liked;
    }
}
