package com.wireout.viewactions;

/**
 * Created by rahul on 4/3/18.
 */

public interface NotificationViewAction extends BaseViewAction {

    public void setNotificationRecyclerView();

}
