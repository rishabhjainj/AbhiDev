package com.wireout.models;

/**
 * Created by sharda on 24/02/18.
 */

abstract public class BaseModel {
    long id;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
