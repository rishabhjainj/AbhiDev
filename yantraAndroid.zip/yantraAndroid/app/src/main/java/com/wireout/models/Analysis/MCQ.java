package com.wireout.models.Analysis;

import java.util.List;

/**
 * Created by sharda on 10/03/18.
 */

public class MCQ {
    String question;
    List<String> answerChoices;
}
